class Producto:
    def _init_(self, nombre, tipo, cantidad, cantidad_minima, precio_base):
        self.nombre = nombre
        self.tipo = tipo
        self.cantidad = cantidad
        self.cantidad_minima = cantidad_minima
        self.precio_base = precio_base
    
    def calcular_precio_final(self):
        impuestos = {
            'papeleria': 0.16,
            'supermercado': 0.04,
            'drogueria': 0.12
        }
        impuesto = impuestos.get(self.tipo, 0)
        return self.precio_base * (1 + impuesto)

class Tienda:
    def _init_(self):
        self.productos = []
    
    def agregar_producto(self, producto):
        nombres = [p.nombre for p in self.productos]
        if producto.nombre in nombres:
            print("Ya existe un producto con ese nombre.")
        else:
            self.productos.append(producto)
            print("Producto agregado correctamente.")
    
    def visualizar_productos(self):
        if not self.productos:
            print("No hay productos en la tienda.")
        else:
            for producto in self.productos:
                print(f"Nombre: {producto.nombre}")
                print(f"Tipo: {producto.tipo}")
                print(f"Cantidad: {producto.cantidad}")
                print(f"Cantidad mínima para abastecimiento: {producto.cantidad_minima}")
                print(f"Precio base de venta por unidad: {producto.precio_base}")
                print(f"Precio final de venta por unidad: {producto.calcular_precio_final()}")
                print("---------------------")
    
    def vender_producto(self, nombre, cantidad):
        producto = self.buscar_producto(nombre)
        if producto:
            if producto.cantidad >= cantidad:
                producto.cantidad -= cantidad
                print(f"Venta realizada. Total: ${producto.calcular_precio_final() * cantidad}")
            else:
                print("No hay suficiente cantidad de producto en la tienda.")
        else:
            print("El producto no existe en la tienda.")
    
    def abastecer_producto(self, nombre, cantidad):
        producto = self.buscar_producto(nombre)
        if producto:
            producto.cantidad += cantidad
            print("Producto abastecido correctamente.")
        else:
            print("El producto no existe en la tienda.")
    
    def buscar_producto(self, nombre):
        for producto in self.productos:
            if producto.nombre == nombre:
                return producto
        return None
    
    def estadisticas_ventas(self):
        if not self.productos:
            print("No hay productos en la tienda.")
        else:
            productos_vendidos = [producto for producto in self.productos if producto.cantidad < producto.cantidad_minima]
            if productos_vendidos:
                producto_mas_vendido = max(productos_vendidos, key=lambda p: p.cantidad)
                producto_menos_vendido = min(productos_vendidos, key=lambda p: p.cantidad)
                cantidad_total_dinero = sum(p.calcular_precio_final() * (p.cantidad_minima - p.cantidad) for p in productos_vendidos)
                cantidad_promedio_dinero = cantidad_total_dinero / sum(p.cantidad_minima - p.cantidad for p in productos_vendidos)
                
                print(f"Producto más vendido: {producto_mas_vendido.nombre}")
                print(f"Producto menos vendido: {producto_menos_vendido.nombre}")
